#ifndef ______COMMON_STANDARD_C_LIBRARIES_______
#define ______COMMON_STANDARD_C_LIBRARIES_______

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <wchar.h>




#endif